/*
 * nghttp2 - HTTP/2 C Library
 *
 * Copyright (c) 2012 Tatsuhiro Tsujikawa
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "shrpx_http_downstream_connection.h"

#include "ssl_compat.h"

#ifdef NGHTTP2_OPENSSL_IS_WOLFSSL
#  include <wolfssl/options.h>
#  include <wolfssl/openssl/rand.h>
#else // !defined(NGHTTP2_OPENSSL_IS_WOLFSSL)
#  include <openssl/rand.h>
#endif // !defined(NGHTTP2_OPENSSL_IS_WOLFSSL)

#include "shrpx_client_handler.h"
#include "shrpx_upstream.h"
#include "shrpx_downstream.h"
#include "shrpx_config.h"
#include "shrpx_error.h"
#include "shrpx_http.h"
#include "shrpx_log_config.h"
#include "shrpx_connect_blocker.h"
#include "shrpx_downstream_connection_pool.h"
#include "shrpx_worker.h"
#include "shrpx_http2_session.h"
#include "shrpx_tls.h"
#include "shrpx_log.h"
#include "http2.h"
#include "util.h"

using namespace nghttp2;

namespace shrpx {

namespace {
void timeoutcb(struct ev_loop *loop, ev_timer *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);

  if (w == &conn->rt && !conn->expired_rt()) {
    return;
  }

  if (log_enabled(INFO)) {
    Log{INFO, dconn} << "Time out";
  }

  auto downstream = dconn->get_downstream();
  auto upstream = downstream->get_upstream();
  auto handler = upstream->get_client_handler();
  auto &resp = downstream->response();

  // Do this so that dconn is not pooled
  resp.connection_close = true;

  if (!upstream->downstream_error(dconn, Downstream::EVENT_TIMEOUT)) {
    delete handler;
  }
}
} // namespace

namespace {
void retry_downstream_connection(Downstream *downstream,
                                 unsigned int status_code) {
  auto upstream = downstream->get_upstream();
  auto handler = upstream->get_client_handler();

  assert(!downstream->get_request_header_sent());

  downstream->add_retry();

  if (downstream->no_more_retry()) {
    delete handler;
    return;
  }

  downstream->pop_downstream_connection();
  auto buf = downstream->get_request_buf();
  buf->reset();

  for (;;) {
    auto maybe_dconn = handler->get_downstream_connection(downstream);
    if (!maybe_dconn) {
      downstream->set_request_state(DownstreamState::CONNECT_FAIL);

      if (!(maybe_dconn.error() == Error::TLS_REQUIRED
              ? upstream->on_downstream_abort_request_with_https_redirect(
                  downstream)
              : upstream->on_downstream_abort_request(downstream,
                                                      status_code))) {
        delete handler;
      }

      return;
    }
    if (!downstream->attach_downstream_connection(std::move(*maybe_dconn))) {
      continue;
    }
    if (downstream->push_request_headers()) {
      return;
    }
  }
}
} // namespace

namespace {
void connect_timeoutcb(struct ev_loop *loop, ev_timer *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);
  auto addr = dconn->get_addr();
  auto raddr = dconn->get_raddr();

  Log{WARN, dconn} << "Connect time out; addr=" << util::to_numeric_addr(raddr);

  downstream_failure(addr, raddr);

  auto downstream = dconn->get_downstream();

  retry_downstream_connection(downstream, 504);
}
} // namespace

namespace {
void backend_retry(Downstream *downstream) {
  retry_downstream_connection(downstream, 502);
}
} // namespace

namespace {
void readcb(struct ev_loop *loop, ev_io *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);
  auto downstream = dconn->get_downstream();
  auto upstream = downstream->get_upstream();
  auto handler = upstream->get_client_handler();

  if (auto rv = upstream->downstream_read(dconn); !rv) {
    if (rv.error() == Error::DCONN_RETRY) {
      backend_retry(downstream);
      return;
    }

    delete handler;
  }
}
} // namespace

namespace {
void writecb(struct ev_loop *loop, ev_io *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);
  auto downstream = dconn->get_downstream();
  auto upstream = downstream->get_upstream();
  auto handler = upstream->get_client_handler();

  if (auto rv = upstream->downstream_write(dconn); !rv) {
    if (rv.error() == Error::DCONN_RETRY) {
      backend_retry(downstream);
      return;
    }

    delete handler;
  }
}
} // namespace

namespace {
void connectcb(struct ev_loop *loop, ev_io *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);
  auto downstream = dconn->get_downstream();
  if (!dconn->connected()) {
    backend_retry(downstream);
    return;
  }
  writecb(loop, w, revents);
}
} // namespace

HttpDownstreamConnection::HttpDownstreamConnection(
  const std::shared_ptr<DownstreamAddrGroup> &group, DownstreamAddr *addr,
  struct ev_loop *loop, Worker *worker)
  : conn_(loop, -1, nullptr, worker->get_mcpool(),
          group->shared_addr->timeout.write, group->shared_addr->timeout.read,
          {}, {}, connectcb, readcb, connect_timeoutcb, this,
          get_config()->tls.dyn_rec.warmup_threshold,
          get_config()->tls.dyn_rec.idle_timeout, Proto::HTTP1),
    worker_(worker),
    ssl_ctx_(worker->get_cl_ssl_ctx()),
    group_(group),
    addr_(addr) {}

HttpDownstreamConnection::~HttpDownstreamConnection() {
  if (log_enabled(INFO)) {
    Log{INFO, this} << "Deleted";
  }

  if (dns_query_) {
    auto dns_tracker = worker_->get_dns_tracker();
    dns_tracker->cancel(dns_query_.get());
  }
}

std::expected<void, Error>
HttpDownstreamConnection::attach_downstream(Downstream *downstream) {
  if (log_enabled(INFO)) {
    Log{INFO, this} << "Attaching to DOWNSTREAM:" << downstream;
  }

  downstream_ = downstream;

  if (auto rv = initiate_connection(); !rv) {
    downstream_ = nullptr;
    return rv;
  }

  return {};
}

namespace {
int htp_msg_begincb(llhttp_t *htp);
int htp_hdr_keycb(llhttp_t *htp, const char *data, size_t len);
int htp_hdr_valcb(llhttp_t *htp, const char *data, size_t len);
int htp_hdrs_completecb(llhttp_t *htp);
int htp_bodycb(llhttp_t *htp, const char *data, size_t len);
int htp_msg_completecb(llhttp_t *htp);
} // namespace

constexpr llhttp_settings_t htp_hooks = {
  .on_message_begin = htp_msg_begincb,
  .on_header_field = htp_hdr_keycb,
  .on_header_value = htp_hdr_valcb,
  .on_headers_complete = htp_hdrs_completecb,
  .on_body = htp_bodycb,
  .on_message_complete = htp_msg_completecb,
};

std::expected<void, Error> HttpDownstreamConnection::initiate_connection() {
  int rv;

  auto worker_blocker = worker_->get_connect_blocker();
  if (worker_blocker->blocked()) {
    if (log_enabled(INFO)) {
      Log{INFO, this}
        << "Worker wide backend connection was blocked temporarily";
    }
    return std::unexpected{Error::NETWORK};
  }

  auto &downstreamconf = *worker_->get_downstream_config();

  if (conn_.fd == -1) {
    auto check_dns_result = dns_query_.get() != nullptr;

    if (check_dns_result) {
      assert(addr_->dns);
    }

    auto &connect_blocker = addr_->connect_blocker;

    if (connect_blocker->blocked()) {
      if (log_enabled(INFO)) {
        Log{INFO, this} << "Backend server " << addr_->host << ":"
                        << addr_->port << " was not available temporarily";
      }

      return std::unexpected{Error::NETWORK};
    }

    Address *raddr;

    if (addr_->dns) {
      if (!check_dns_result) {
        auto dns_query = std::make_unique<DNSQuery>(
          addr_->host, [this](DNSResolverStatus status, const Address *result) {
            if (status == DNSResolverStatus::OK) {
              *this->resolved_addr_ = *result;
            }

            if (!this->initiate_connection()) {
              // This callback destroys |this|.
              auto downstream = this->downstream_;
              backend_retry(downstream);
            }
          });

        auto dns_tracker = worker_->get_dns_tracker();

        if (!resolved_addr_) {
          resolved_addr_ = std::make_unique<Address>();
        }
        switch (dns_tracker->resolve(resolved_addr_.get(), dns_query.get())) {
        case DNSResolverStatus::ERROR:
          downstream_failure(addr_, nullptr);
          return std::unexpected{Error::NETWORK};
        case DNSResolverStatus::RUNNING:
          dns_query_ = std::move(dns_query);
          return {};
        case DNSResolverStatus::OK:
          break;
        default:
          assert(0);
        }
      } else {
        switch (dns_query_->status) {
        case DNSResolverStatus::ERROR:
          dns_query_.reset();
          downstream_failure(addr_, nullptr);
          return std::unexpected{Error::NETWORK};
        case DNSResolverStatus::OK:
          dns_query_.reset();
          break;
        default:
          assert(0);
        }
      }

      resolved_addr_->port(addr_->port);
      raddr = resolved_addr_.get();
    } else {
      raddr = &addr_->addr;
    }

    auto maybe_fd = util::create_nonblock_socket(raddr->family());
    if (!maybe_fd) {
      auto error = errno;
      Log{WARN, this} << "socket() failed; addr="
                      << util::to_numeric_addr(raddr) << ", errno=" << error;

      worker_blocker->on_failure();

      return std::unexpected{Error::NETWORK};
    }

    conn_.fd = *maybe_fd;

    worker_blocker->on_success();

    rv = connect(conn_.fd, raddr->as_sockaddr(), raddr->size());
    if (rv != 0 && errno != EINPROGRESS) {
      auto error = errno;
      Log{WARN, this} << "connect() failed; addr="
                      << util::to_numeric_addr(raddr) << ", errno=" << error;

      downstream_failure(addr_, raddr);

      return std::unexpected{Error::NETWORK};
    }

    if (log_enabled(INFO)) {
      Log{INFO, this} << "Connecting to downstream server";
    }

    raddr_ = raddr;

    if (addr_->tls) {
      assert(ssl_ctx_);

      auto maybe_ssl = tls::create_ssl(ssl_ctx_);
      if (!maybe_ssl) {
        return std::unexpected{maybe_ssl.error()};
      }

      auto ssl = *maybe_ssl;

      tls::setup_downstream_http1_alpn(ssl);

      conn_.set_ssl(ssl);
      conn_.tls.client_session_cache = &addr_->tls_session_cache;

      auto sni_name = addr_->sni.empty() ? addr_->host : addr_->sni;
      if (!util::numeric_host(sni_name.data())) {
        SSL_set_tlsext_host_name(conn_.tls.ssl, sni_name.data());
      }

      auto maybe_session = tls::reuse_tls_session(addr_->tls_session_cache);
      if (maybe_session) {
        auto session = *maybe_session;
        SSL_set_session(conn_.tls.ssl, session);
        SSL_SESSION_free(session);
      }

      conn_.prepare_client_handshake();
    }

    ev_io_set(&conn_.wev, conn_.fd, EV_WRITE);
    ev_io_set(&conn_.rev, conn_.fd, EV_READ);

    conn_.wlimit.startw();

    conn_.wt.repeat = downstreamconf.timeout.connect;
    ev_timer_again(conn_.loop, &conn_.wt);
  } else {
    // we may set read timer cb to idle_timeoutcb.  Reset again.
    ev_set_cb(&conn_.rt, timeoutcb);
    if (conn_.read_timeout < group_->shared_addr->timeout.read) {
      conn_.read_timeout = group_->shared_addr->timeout.read;
      conn_.last_read = std::chrono::steady_clock::now();
    } else {
      conn_.again_rt(group_->shared_addr->timeout.read);
    }

    ev_set_cb(&conn_.rev, readcb);

    on_write_ = &HttpDownstreamConnection::write_first;
    first_write_done_ = false;
    request_header_written_ = false;
  }

  llhttp_init(&response_htp_, HTTP_RESPONSE, &htp_hooks);
  response_htp_.data = downstream_;

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::push_request_headers() {
  if (request_header_written_) {
    signal_write();
    return {};
  }

  const auto &req = downstream_->request();

  auto &balloc = downstream_->get_block_allocator();

  auto connect_method = req.regular_connect_method();

  auto config = get_config();
  auto &httpconf = config->http;

  request_header_written_ = true;

  // For HTTP/1.0 request, there is no authority in request.  In that
  // case, we use backend server's host nonetheless.
  auto authority = addr_->hostport;
  auto no_host_rewrite =
    httpconf.no_host_rewrite || config->http2_proxy || connect_method;

  if (no_host_rewrite && !req.authority.empty()) {
    authority = req.authority;
  }

  downstream_->set_request_downstream_host(authority);

  auto buf = downstream_->get_request_buf();

  // Assume that method and request path do not contain \r\n.
  auto meth = http2::to_method_string(
    req.connect_proto == ConnectProto::WEBSOCKET ? HTTP_GET : req.method);
  buf->append(meth);
  buf->append(' ');

  if (connect_method) {
    buf->append(authority);
  } else if (config->http2_proxy) {
    // Construct absolute-form request target because we are going to
    // send a request to a HTTP/1 proxy.
    assert(!req.scheme.empty());
    buf->append(req.scheme);
    buf->append("://"sv);
    buf->append(authority);
    buf->append(req.path);
  } else if (req.method == HTTP_OPTIONS && req.path.empty()) {
    // Server-wide OPTIONS
    buf->append('*');
  } else {
    buf->append(req.path);
  }
  buf->append(" HTTP/1.1\r\nHost: "sv);
  buf->append(authority);
  buf->append("\r\n"sv);

  auto &fwdconf = httpconf.forwarded;
  auto &xffconf = httpconf.xff;
  auto &xfpconf = httpconf.xfp;
  auto &earlydataconf = httpconf.early_data;

  uint32_t build_flags =
    (fwdconf.strip_incoming ? http2::HDOP_STRIP_FORWARDED : 0) |
    (xffconf.strip_incoming ? http2::HDOP_STRIP_X_FORWARDED_FOR : 0) |
    (xfpconf.strip_incoming ? http2::HDOP_STRIP_X_FORWARDED_PROTO : 0) |
    (earlydataconf.strip_incoming ? http2::HDOP_STRIP_EARLY_DATA : 0) |
    ((req.http_major == 3 || req.http_major == 2)
       ? http2::HDOP_STRIP_SEC_WEBSOCKET_KEY
       : 0);

  http2::build_http1_headers_from_headers(buf, req.fs.headers(), build_flags);

  auto cookie = downstream_->assemble_request_cookie();
  if (!cookie.empty()) {
    buf->append("Cookie: "sv);
    buf->append(cookie);
    buf->append("\r\n"sv);
  }

  // set transfer-encoding only when content-length is unknown and
  // request body is expected.
  if (req.method != HTTP_CONNECT && req.http2_expect_body &&
      req.fs.content_length == -1) {
    downstream_->set_chunked_request(true);
    buf->append("Transfer-Encoding: chunked\r\n"sv);
  }

  if (req.connect_proto == ConnectProto::WEBSOCKET) {
    if (req.http_major == 3 || req.http_major == 2) {
      std::array<uint8_t, 16> nonce;
      if (RAND_bytes(nonce.data(), nonce.size()) != 1) {
        return std::unexpected{Error::CRYPTO};
      }
      auto iov = make_byte_ref(balloc, base64::encode_length(nonce.size()) + 1);
      auto p = base64::encode(nonce, std::ranges::begin(iov));
      *p = '\0';
      auto key = as_string_view(std::ranges::begin(iov), p);
      downstream_->set_ws_key(key);

      buf->append("Sec-Websocket-Key: "sv);
      buf->append(key);
      buf->append("\r\n"sv);
    }

    buf->append("Upgrade: websocket\r\nConnection: Upgrade\r\n"sv);
  } else if (!connect_method && req.upgrade_request) {
    auto connection = req.fs.header(http2::HD_CONNECTION);
    if (connection) {
      buf->append("Connection: "sv);
      buf->append((*connection).value);
      buf->append("\r\n"sv);
    }

    auto upgrade = req.fs.header(http2::HD_UPGRADE);
    if (upgrade) {
      buf->append("Upgrade: "sv);
      buf->append((*upgrade).value);
      buf->append("\r\n"sv);
    }
  } else if (req.connection_close) {
    buf->append("Connection: close\r\n"sv);
  }

  auto upstream = downstream_->get_upstream();
  auto handler = upstream->get_client_handler();

#if defined(NGHTTP2_GENUINE_OPENSSL) ||                                        \
  defined(NGHTTP2_OPENSSL_IS_BORINGSSL) || defined(NGHTTP2_OPENSSL_IS_WOLFSSL)
  auto conn = handler->get_connection();

  if (conn->tls.ssl && !SSL_is_init_finished(conn->tls.ssl)) {
    buf->append("Early-Data: 1\r\n"sv);
  }
#endif // defined(NGHTTP2_GENUINE_OPENSSL) ||
       // defined(NGHTTP2_OPENSSL_IS_BORINGSSL) ||
       // defined(NGHTTP2_OPENSSL_IS_WOLFSSL)

  auto fwd =
    fwdconf.strip_incoming ? nullptr : req.fs.header(http2::HD_FORWARDED);

  if (fwdconf.params) {
    auto params = fwdconf.params;

    if (config->http2_proxy || connect_method) {
      params &= static_cast<uint32_t>(~FORWARDED_PROTO);
    }

    auto value = http::create_forwarded(
      balloc, params, handler->get_forwarded_by(), handler->get_forwarded_for(),
      req.authority, req.scheme);

    if (fwd || !value.empty()) {
      buf->append("Forwarded: "sv);
      if (fwd) {
        buf->append(fwd->value);

        if (!value.empty()) {
          buf->append(", "sv);
        }
      }
      buf->append(value);
      buf->append("\r\n"sv);
    }
  } else if (fwd) {
    buf->append("Forwarded: "sv);
    buf->append(fwd->value);
    buf->append("\r\n"sv);
  }

  auto xff =
    xffconf.strip_incoming ? nullptr : req.fs.header(http2::HD_X_FORWARDED_FOR);

  if (xffconf.add) {
    buf->append("X-Forwarded-For: "sv);
    if (xff) {
      buf->append((*xff).value);
      buf->append(", "sv);
    }
    buf->append(client_handler_->get_ipaddr());
    buf->append("\r\n"sv);
  } else if (xff) {
    buf->append("X-Forwarded-For: "sv);
    buf->append((*xff).value);
    buf->append("\r\n"sv);
  }
  if (!config->http2_proxy && !connect_method) {
    auto xfp = xfpconf.strip_incoming
                 ? nullptr
                 : req.fs.header(http2::HD_X_FORWARDED_PROTO);

    if (xfpconf.add) {
      buf->append("X-Forwarded-Proto: "sv);
      if (xfp) {
        buf->append((*xfp).value);
        buf->append(", "sv);
      }
      assert(!req.scheme.empty());
      buf->append(req.scheme);
      buf->append("\r\n"sv);
    } else if (xfp) {
      buf->append("X-Forwarded-Proto: "sv);
      buf->append((*xfp).value);
      buf->append("\r\n"sv);
    }
  }
  auto via = req.fs.header(http2::HD_VIA);
  if (httpconf.no_via) {
    if (via) {
      buf->append("Via: "sv);
      buf->append((*via).value);
      buf->append("\r\n"sv);
    }
  } else {
    buf->append("Via: "sv);
    if (via) {
      buf->append((*via).value);
      buf->append(", "sv);
    }

    buf->append(16, std::bind_front(http::ViaValueGenerator{}, req.http_major,
                                    req.http_minor));
    buf->append("\r\n"sv);
  }

  for (auto &p : httpconf.add_request_headers) {
    buf->append(p.name);
    buf->append(": "sv);
    buf->append(p.value);
    buf->append("\r\n"sv);
  }

  buf->append("\r\n"sv);

  if (log_enabled(INFO)) {
    std::string nhdrs;
    for (auto chunk = buf->head; chunk; chunk = chunk->next) {
      nhdrs.append(chunk->pos, chunk->last);
    }
    if (log_config()->errorlog_tty) {
      nhdrs = http::colorize_headers(nhdrs);
    }
    Log{INFO, this} << "HTTP request headers. stream_id="
                    << downstream_->get_stream_id() << "\n"
                    << nhdrs;
  }

  // Don't call signal_write() if we anticipate request body.  We call
  // signal_write() when we received request body chunk, and it
  // enables us to send headers and data in one writev system call.
  if (req.method == HTTP_CONNECT ||
      downstream_->get_blocked_request_buf()->rleft() ||
      (!req.http2_expect_body && req.fs.content_length == 0) ||
      downstream_->get_expect_100_continue()) {
    signal_write();
  }

  return {};
}

bool HttpDownstreamConnection::should_block_request_body() const {
  const auto &req = downstream_->request();

  return !downstream_->get_request_header_sent() ||
         (req.upgrade_request && !downstream_->get_upgraded());
}

bool HttpDownstreamConnection::should_unblock_request_body_before_response()
  const {
  const auto &req = downstream_->request();

  return !req.upgrade_request;
}

void HttpDownstreamConnection::process_blocked_request_buf_on_response() {
  if (blocked_request_buf_processed_) {
    return;
  }

  process_blocked_request_buf();

  auto buf = downstream_->get_blocked_request_buf();
  buf->reset();
  blocked_request_buf_processed_ = true;

  signal_write();
}

void HttpDownstreamConnection::process_blocked_request_buf() {
  auto src = downstream_->get_blocked_request_buf();

  if (src->rleft()) {
    auto dest = downstream_->get_request_buf();
    auto chunked = downstream_->get_chunked_request();
    if (chunked) {
      dest->append(sizeof(size_t) * 2,
                   std::bind_front(util::CompactHexFormatter{}, src->rleft()));
      dest->append("\r\n"sv);
    }

    src->copy(*dest);

    if (chunked) {
      dest->append("\r\n"sv);
    }
  }

  if (downstream_->get_blocked_request_data_eof() &&
      downstream_->get_chunked_request()) {
    end_upload_data_chunk();
  }
}

std::expected<void, Error> HttpDownstreamConnection::push_upload_data_chunk(
  std::span<const uint8_t> data) {
  if (should_block_request_body()) {
    auto output = downstream_->get_blocked_request_buf();
    auto &req = downstream_->request();
    output->append(data);
    req.unconsumed_body_length += data.size();
    if (request_header_written_) {
      signal_write();
    }
    return {};
  }

  auto chunked = downstream_->get_chunked_request();
  auto output = downstream_->get_request_buf();

  if (chunked) {
    output->append(sizeof(data.size()) * 2,
                   std::bind_front(util::CompactHexFormatter{}, data.size()));
    output->append("\r\n"sv);
  }

  output->append(data);

  if (chunked) {
    output->append("\r\n"sv);
  }

  signal_write();

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::end_upload_data() {
  if (should_block_request_body()) {
    downstream_->set_blocked_request_data_eof(true);
    if (request_header_written_) {
      signal_write();
    }
    return {};
  }

  signal_write();

  if (!downstream_->get_chunked_request()) {
    return {};
  }

  end_upload_data_chunk();

  return {};
}

void HttpDownstreamConnection::end_upload_data_chunk() {
  const auto &req = downstream_->request();

  auto output = downstream_->get_request_buf();
  const auto &trailers = req.fs.trailers();
  if (trailers.empty()) {
    output->append("0\r\n\r\n"sv);
  } else {
    output->append("0\r\n"sv);
    http2::build_http1_headers_from_headers(output, trailers,
                                            http2::HDOP_STRIP_ALL);
    output->append("\r\n"sv);
  }
}

namespace {
void remove_from_pool(HttpDownstreamConnection *dconn) {
  auto addr = dconn->get_addr();
  auto &dconn_pool = addr->dconn_pool;
  dconn_pool->remove_downstream_connection(dconn);
}
} // namespace

namespace {
void idle_readcb(struct ev_loop *loop, ev_io *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);
  if (log_enabled(INFO)) {
    Log{INFO, dconn} << "Idle connection EOF";
  }

  remove_from_pool(dconn);
  // dconn was deleted
}
} // namespace

namespace {
void idle_timeoutcb(struct ev_loop *loop, ev_timer *w, int revents) {
  auto conn = static_cast<Connection *>(w->data);
  auto dconn = static_cast<HttpDownstreamConnection *>(conn->data);

  if (w == &conn->rt && !conn->expired_rt()) {
    return;
  }

  if (log_enabled(INFO)) {
    Log{INFO, dconn} << "Idle connection timeout";
  }

  remove_from_pool(dconn);
  // dconn was deleted
}
} // namespace

std::expected<void, Error>
HttpDownstreamConnection::detach_downstream(Downstream *downstream) {
  if (log_enabled(INFO)) {
    Log{INFO, this} << "Detaching from DOWNSTREAM:" << downstream;
  }
  downstream_ = nullptr;

  ev_set_cb(&conn_.rev, idle_readcb);
  ioctrl_.force_resume_read();

  auto &downstreamconf = *worker_->get_downstream_config();

  ev_set_cb(&conn_.rt, idle_timeoutcb);
  if (conn_.read_timeout < downstreamconf.timeout.idle_read) {
    conn_.read_timeout = downstreamconf.timeout.idle_read;
    conn_.last_read = std::chrono::steady_clock::now();
  } else {
    conn_.again_rt(downstreamconf.timeout.idle_read);
  }

  conn_.wlimit.stopw();
  ev_timer_stop(conn_.loop, &conn_.wt);

  return {};
}

void HttpDownstreamConnection::pause_read(IOCtrlReason reason) {
  ioctrl_.pause_read(reason);
}

std::expected<void, Error>
HttpDownstreamConnection::resume_read(IOCtrlReason reason, size_t consumed) {
  auto &downstreamconf = *worker_->get_downstream_config();

  if (downstream_->get_response_buf()->rleft() <=
      downstreamconf.request_buffer_size / 2) {
    ioctrl_.resume_read(reason);
  }

  return {};
}

void HttpDownstreamConnection::force_resume_read() {
  ioctrl_.force_resume_read();
}

namespace {
int htp_msg_begincb(llhttp_t *htp) {
  auto downstream = static_cast<Downstream *>(htp->data);

  if (downstream->get_response_state() != DownstreamState::INITIAL) {
    return -1;
  }

  return 0;
}
} // namespace

namespace {
int htp_hdrs_completecb(llhttp_t *htp) {
  auto downstream = static_cast<Downstream *>(htp->data);
  auto upstream = downstream->get_upstream();
  auto handler = upstream->get_client_handler();
  const auto &req = downstream->request();
  auto &resp = downstream->response();
  auto &balloc = downstream->get_block_allocator();

  for (auto &kv : resp.fs.headers()) {
    kv.value = util::rstrip(balloc, kv.value);

    if (kv.token == http2::HD_TRANSFER_ENCODING &&
        !http2::check_transfer_encoding(kv.value)) {
      return -1;
    }
  }

  auto config = get_config();
  auto &loggingconf = config->logging;

  resp.http_status = htp->status_code;
  resp.http_major = htp->http_major;
  resp.http_minor = htp->http_minor;

  if (resp.http_major > 1 || req.http_minor > 1) {
    resp.http_major = 1;
    resp.http_minor = 1;
    return -1;
  }

  auto dconn = downstream->get_downstream_connection();

  downstream->set_downstream_addr_group(dconn->get_downstream_addr_group());
  downstream->set_addr(dconn->get_addr());

  // Server MUST NOT send Transfer-Encoding with a status code 1xx or
  // 204.  Also server MUST NOT send Transfer-Encoding with a status
  // code 2xx to a CONNECT request.  Same holds true with
  // Content-Length.
  if (resp.http_status == 204) {
    if (resp.fs.header(http2::HD_TRANSFER_ENCODING)) {
      return -1;
    }
    // Some server send content-length: 0 for 204.  Until they get
    // fixed, we accept, but ignore it.

    // Calling parse_content_length() detects duplicated
    // content-length header fields.
    if (!resp.fs.parse_content_length()) {
      return -1;
    }
    if (resp.fs.content_length == 0) {
      resp.fs.erase_content_length_and_transfer_encoding();
    } else if (resp.fs.content_length != -1) {
      return -1;
    }
  } else if (resp.http_status / 100 == 1 ||
             (resp.http_status / 100 == 2 && req.method == HTTP_CONNECT)) {
    // Server MUST NOT send Content-Length and Transfer-Encoding in
    // these responses.
    resp.fs.erase_content_length_and_transfer_encoding();
  } else if (!resp.fs.parse_content_length()) {
    downstream->set_response_state(DownstreamState::MSG_BAD_HEADER);
    return -1;
  }

  // Check upgrade before processing non-final response, since if
  // upgrade succeeded, 101 response is treated as final in nghttpx.
  downstream->check_upgrade_fulfilled_http1();

  if (req.method == HTTP_CONNECT && resp.http_status / 100 == 2 &&
      !downstream->get_upgraded()) {
    resp.http_status = 502;
  }

  if (downstream->get_non_final_response()) {
    // Reset content-length because we reuse same Downstream for the
    // next response.
    resp.fs.content_length = -1;
    // For non-final response code, we just call
    // on_downstream_header_complete() without changing response
    // state.
    if (!upstream->on_downstream_header_complete(downstream)) {
      return -1;
    }

    // Ignore response body for non-final response.
    return 1;
  }

  resp.connection_close = !llhttp_should_keep_alive(htp);
  downstream->set_response_state(DownstreamState::HEADER_COMPLETE);
  downstream->inspect_http1_response();

  if (!downstream->get_upgraded() && (htp->flags & F_CHUNKED)) {
    downstream->set_chunked_response(true);
  }

  auto transfer_encoding = resp.fs.header(http2::HD_TRANSFER_ENCODING);
  if (transfer_encoding && !downstream->get_chunked_response()) {
    resp.connection_close = true;
  }

  if (downstream->get_upgraded()) {
    // content-length must be ignored for upgraded connection.
    resp.fs.content_length = -1;
    resp.connection_close = true;
    // transfer-encoding not applied to upgraded connection
    downstream->set_chunked_response(false);

    static_cast<HttpDownstreamConnection *>(dconn)
      ->process_blocked_request_buf_on_response();
  } else {
    if (req.upgrade_request) {
      resp.connection_close = true;
    }

    if (http2::legacy_http1(req.http_major, req.http_minor)) {
      if (resp.fs.content_length == -1) {
        resp.connection_close = true;
      }
      downstream->set_chunked_response(false);
    } else if (!downstream->expect_response_body()) {
      downstream->set_chunked_response(false);
    }
  }

  if (loggingconf.access.write_early && downstream->accesslog_ready()) {
    handler->write_accesslog(downstream);
    downstream->set_accesslog_written(true);
  }

  if (!upstream->on_downstream_header_complete(downstream)) {
    return -1;
  }

  if (downstream->get_upgraded()) {
    // Upgrade complete, read until EOF in both ends
    if (!upstream->resume_read(SHRPX_NO_BUFFER, downstream, 0)) {
      return -1;
    }
    downstream->set_request_state(DownstreamState::HEADER_COMPLETE);
    if (log_enabled(INFO)) {
      Log{INFO} << "HTTP upgrade success. stream_id="
                << downstream->get_stream_id();
    }
  }

  // Ignore the response body. HEAD response may contain
  // Content-Length or Transfer-Encoding: chunked.  Some server send
  // 304 status code with nonzero Content-Length, but without response
  // body. See
  // https://tools.ietf.org/html/rfc7230#section-3.3

  // TODO It seems that the cases other than HEAD are handled by
  // llhttp.  Need test.
  return !http2::expect_response_body(req.method, resp.http_status);
}
} // namespace

namespace {
std::expected<void, Error>
ensure_header_field_buffer(const Downstream *downstream,
                           const HttpConfig &httpconf, size_t len) {
  auto &resp = downstream->response();

  if (resp.fs.buffer_size() + len > httpconf.response_header_field_buffer) {
    if (log_enabled(INFO)) {
      Log{INFO, downstream} << "Too large header header field size="
                            << resp.fs.buffer_size() + len;
    }
    return std::unexpected{Error::HTTP_FIELD_TOO_LARGE};
  }

  return {};
}
} // namespace

namespace {
std::expected<void, Error>
ensure_max_header_fields(const Downstream *downstream,
                         const HttpConfig &httpconf) {
  auto &resp = downstream->response();

  if (resp.fs.num_fields() >= httpconf.max_response_header_fields) {
    if (log_enabled(INFO)) {
      Log{INFO, downstream} << "Too many header field num="
                            << resp.fs.num_fields() + 1;
    }
    return std::unexpected{Error::HTTP_FIELD_TOO_LARGE};
  }

  return {};
}
} // namespace

namespace {
int htp_hdr_keycb(llhttp_t *htp, const char *data, size_t len) {
  auto downstream = static_cast<Downstream *>(htp->data);
  auto &resp = downstream->response();
  auto &httpconf = get_config()->http;

  if (!ensure_header_field_buffer(downstream, httpconf, len)) {
    return -1;
  }

  auto name = std::string_view{data, len};

  if (downstream->get_response_state() == DownstreamState::INITIAL) {
    if (resp.fs.header_key_prev()) {
      resp.fs.append_last_header_key(name);
    } else {
      if (!ensure_max_header_fields(downstream, httpconf)) {
        return -1;
      }
      resp.fs.alloc_add_header_name(name);
    }
  } else {
    // trailer part
    if (resp.fs.trailer_key_prev()) {
      resp.fs.append_last_trailer_key(name);
    } else {
      if (!ensure_max_header_fields(downstream, httpconf)) {
        // Could not ignore this trailer field easily, since we may
        // get its value in htp_hdr_valcb, and it will be added to
        // wrong place or crash if trailer fields are currently empty.
        return -1;
      }
      resp.fs.alloc_add_trailer_name(name);
    }
  }
  return 0;
}
} // namespace

namespace {
int htp_hdr_valcb(llhttp_t *htp, const char *data, size_t len) {
  auto downstream = static_cast<Downstream *>(htp->data);
  auto &resp = downstream->response();
  auto &httpconf = get_config()->http;

  if (!ensure_header_field_buffer(downstream, httpconf, len)) {
    return -1;
  }

  auto value = std::string_view{data, len};

  if (downstream->get_response_state() == DownstreamState::INITIAL) {
    resp.fs.append_last_header_value(value);
  } else {
    resp.fs.append_last_trailer_value(value);
  }
  return 0;
}
} // namespace

namespace {
int htp_bodycb(llhttp_t *htp, const char *data, size_t len) {
  auto downstream = static_cast<Downstream *>(htp->data);
  auto &resp = downstream->response();

  resp.recv_body_length += len;

  if (!downstream->get_upstream()->on_downstream_body(
        downstream, as_uint8_span(std::span{data, len}), true)) {
    return -1;
  }

  return 0;
}
} // namespace

namespace {
int htp_msg_completecb(llhttp_t *htp) {
  auto downstream = static_cast<Downstream *>(htp->data);
  auto &resp = downstream->response();
  auto &balloc = downstream->get_block_allocator();

  for (auto &kv : resp.fs.trailers()) {
    kv.value = util::rstrip(balloc, kv.value);
  }

  // llhttp does not treat "200 connection established" response
  // against CONNECT request, and in that case, this function is not
  // called.  But if HTTP Upgrade is made (e.g., WebSocket), this
  // function is called, and llhttp_execute() returns just after that.
  if (downstream->get_upgraded()) {
    return 0;
  }

  if (downstream->get_non_final_response()) {
    downstream->reset_response();

    return 0;
  }

  downstream->set_response_state(DownstreamState::MSG_COMPLETE);
  // Block reading another response message from (broken?)
  // server. This callback is not called if the connection is
  // tunneled.
  downstream->pause_read(SHRPX_MSG_BLOCK);

  if (!downstream->get_upstream()->on_downstream_body_complete(downstream)) {
    return -1;
  }

  return 0;
}
} // namespace

std::expected<void, Error> HttpDownstreamConnection::write_first() {
  auto should_unblock_req_body = should_unblock_request_body_before_response();
  if (should_unblock_req_body) {
    process_blocked_request_buf();
  }

  if (auto rv = conn_.tls.ssl ? write_tls() : write_clear(); !rv) {
    return std::unexpected{Error::DCONN_RETRY};
  }

  if (conn_.tls.ssl) {
    on_write_ = &HttpDownstreamConnection::write_tls;
  } else {
    on_write_ = &HttpDownstreamConnection::write_clear;
  }

  first_write_done_ = true;
  downstream_->set_request_header_sent(true);

  if (should_unblock_req_body) {
    auto buf = downstream_->get_blocked_request_buf();
    buf->reset();
    blocked_request_buf_processed_ = true;
  }

  // upstream->resume_read() might be called in
  // write_tls()/write_clear(), but before blocked_request_buf_ is
  // reset.  So upstream read might still be blocked.  Let's do it
  // again here.
  auto input = downstream_->get_request_buf();
  if (input->rleft() == 0) {
    auto upstream = downstream_->get_upstream();
    auto &req = downstream_->request();

    if (auto rv = upstream->resume_read(SHRPX_NO_BUFFER, downstream_,
                                        req.unconsumed_body_length);
        !rv) {
      return rv;
    }
  }

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::read_clear() {
  conn_.last_read = std::chrono::steady_clock::now();

  std::array<uint8_t, 16_k> rawbuf;
  auto buf = std::span{rawbuf};

  for (;;) {
    auto maybe_data = conn_.read_clear(buf);
    if (!maybe_data) {
      if (maybe_data.error() == Error::RECV_EOF &&
          !downstream_->get_upgraded()) {
        auto htperr = llhttp_finish(&response_htp_);
        if (htperr != HPE_OK) {
          if (log_enabled(INFO)) {
            Log{INFO, this} << "HTTP response ended prematurely: "
                            << llhttp_errno_name(htperr);
          }

          return std::unexpected{Error::HTTP1};
        }
      }

      return std::unexpected{maybe_data.error()};
    }

    auto data = *maybe_data;
    if (data.empty()) {
      return {};
    }

    if (auto rv = process_input(data); !rv) {
      return rv;
    }

    if (!ev_is_active(&conn_.rev)) {
      return {};
    }
  }
}

std::expected<void, Error> HttpDownstreamConnection::write_clear() {
  conn_.last_read = std::chrono::steady_clock::now();

  auto upstream = downstream_->get_upstream();
  auto input = downstream_->get_request_buf();

  std::array<struct iovec, MAX_WR_IOVCNT> iovbuf;

  for (;;) {
    auto iov = input->riovec(iovbuf);
    if (iov.empty()) {
      break;
    }

    auto maybe_nwrite = conn_.writev_clear(iov);
    if (!maybe_nwrite) {
      if (!first_write_done_) {
        return std::unexpected{maybe_nwrite.error()};
      }
      // We may have pending data in receive buffer which may contain
      // part of response body.  So keep reading.  Invoke read event
      // to get read(2) error just in case.
      ev_feed_event(conn_.loop, &conn_.rev, EV_READ);
      on_write_ = &HttpDownstreamConnection::noop;
      reusable_ = false;
      break;
    }

    auto nwrite = *maybe_nwrite;
    if (nwrite == 0) {
      return {};
    }

    input->drain(nwrite);
  }

  conn_.wlimit.stopw();
  ev_timer_stop(conn_.loop, &conn_.wt);

  if (input->rleft() == 0) {
    auto &req = downstream_->request();

    if (auto rv = upstream->resume_read(SHRPX_NO_BUFFER, downstream_,
                                        req.unconsumed_body_length);
        !rv) {
      return rv;
    }
  }

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::tls_handshake() {
  ERR_clear_error();

  conn_.last_read = std::chrono::steady_clock::now();

  if (auto rv = conn_.tls_handshake(); !rv) {
    if (rv.error() == Error::TLS_HANDSHAKE_INPROGRESS) {
      return {};
    }

    downstream_failure(addr_, raddr_);

    return rv;
  }

  if (log_enabled(INFO)) {
    Log{INFO, this} << "SSL/TLS handshake completed";
  }

  if (!get_config()->tls.insecure) {
    if (auto rv = tls::check_cert(conn_.tls.ssl, addr_, raddr_); !rv) {
      downstream_failure(addr_, raddr_);

      return rv;
    }
  }

  auto &connect_blocker = addr_->connect_blocker;

  signal_write_ = &HttpDownstreamConnection::actual_signal_write;

  connect_blocker->on_success();

  ev_set_cb(&conn_.rt, timeoutcb);
  ev_set_cb(&conn_.wt, timeoutcb);

  on_read_ = &HttpDownstreamConnection::read_tls;
  on_write_ = &HttpDownstreamConnection::write_first;

  // TODO Check negotiated ALPN

  return on_write();
}

std::expected<void, Error> HttpDownstreamConnection::read_tls() {
  conn_.last_read = std::chrono::steady_clock::now();

  ERR_clear_error();

  std::array<uint8_t, 16_k> rawbuf;
  auto buf = std::span{rawbuf};

  for (;;) {
    auto maybe_data = conn_.read_tls(buf);
    if (!maybe_data) {
      if (maybe_data.error() == Error::RECV_EOF &&
          !downstream_->get_upgraded()) {
        auto htperr = llhttp_finish(&response_htp_);
        if (htperr != HPE_OK) {
          if (log_enabled(INFO)) {
            Log{INFO, this} << "HTTP response ended prematurely: "
                            << llhttp_errno_name(htperr);
          }

          return std::unexpected{Error::HTTP1};
        }
      }

      return std::unexpected{maybe_data.error()};
    }

    auto data = *maybe_data;
    if (data.empty()) {
      return {};
    }

    if (auto rv = process_input(data); !rv) {
      return rv;
    }

    if (!ev_is_active(&conn_.rev)) {
      return {};
    }
  }
}

std::expected<void, Error> HttpDownstreamConnection::write_tls() {
  conn_.last_read = std::chrono::steady_clock::now();

  ERR_clear_error();

  auto upstream = downstream_->get_upstream();
  auto input = downstream_->get_request_buf();

  for (;;) {
    auto data = input->peek();
    if (data.empty()) {
      break;
    }

    auto maybe_nwrite = conn_.write_tls(data);
    if (!maybe_nwrite) {
      if (!first_write_done_) {
        return std::unexpected{maybe_nwrite.error()};
      }
      // We may have pending data in receive buffer which may contain
      // part of response body.  So keep reading.  Invoke read event
      // to get read(2) error just in case.
      ev_feed_event(conn_.loop, &conn_.rev, EV_READ);
      on_write_ = &HttpDownstreamConnection::noop;
      reusable_ = false;
      break;
    }

    auto nwrite = *maybe_nwrite;
    if (nwrite == 0) {
      return {};
    }

    input->drain(nwrite);
  }

  conn_.wlimit.stopw();
  ev_timer_stop(conn_.loop, &conn_.wt);

  if (input->rleft() == 0) {
    conn_.start_tls_write_idle();

    auto &req = downstream_->request();

    if (auto rv = upstream->resume_read(SHRPX_NO_BUFFER, downstream_,
                                        req.unconsumed_body_length);
        !rv) {
      return rv;
    }
  }

  return {};
}

std::expected<void, Error>
HttpDownstreamConnection::process_input(std::span<const uint8_t> data) {
  if (downstream_->get_upgraded()) {
    // For upgraded connection, just pass data to the upstream.
    if (auto rv = downstream_->get_upstream()->on_downstream_body(downstream_,
                                                                  data, true);
        !rv) {
      return rv;
    }

    if (downstream_->response_buf_full()) {
      downstream_->pause_read(SHRPX_NO_BUFFER);
      return {};
    }

    return {};
  }

  auto htperr = llhttp_execute(
    &response_htp_, reinterpret_cast<const char *>(data.data()), data.size());
  auto nproc = htperr == HPE_OK
                 ? data.size()
                 : static_cast<size_t>(reinterpret_cast<const uint8_t *>(
                                         llhttp_get_error_pos(&response_htp_)) -
                                       data.data());

  if (htperr != HPE_OK &&
      (!downstream_->get_upgraded() || htperr != HPE_PAUSED_UPGRADE)) {
    // Handling early return (in other words, response was hijacked by
    // mruby scripting).
    if (downstream_->get_response_state() == DownstreamState::MSG_COMPLETE) {
      return std::unexpected{Error::DCONN_CANCELED};
    }

    if (log_enabled(INFO)) {
      Log{INFO, this} << "HTTP parser failure: "
                      << "(" << llhttp_errno_name(htperr) << ") "
                      << llhttp_get_error_reason(&response_htp_);
    }

    return std::unexpected{Error::HTTP1};
  }

  if (downstream_->get_upgraded()) {
    if (nproc < data.size()) {
      // Data from data + nproc are for upgraded protocol.
      if (auto rv = downstream_->get_upstream()->on_downstream_body(
            downstream_, data.subspan(nproc), true);
          !rv) {
        return rv;
      }

      if (downstream_->response_buf_full()) {
        downstream_->pause_read(SHRPX_NO_BUFFER);
        return {};
      }
    }
    return {};
  }

  if (downstream_->response_buf_full()) {
    downstream_->pause_read(SHRPX_NO_BUFFER);
    return {};
  }

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::connected() {
  auto &connect_blocker = addr_->connect_blocker;

  auto sock_error = util::get_socket_error(conn_.fd);
  if (sock_error != 0) {
    conn_.wlimit.stopw();

    Log{WARN, this} << "Backend connect failed; addr="
                    << util::to_numeric_addr(raddr_)
                    << ": errno=" << sock_error;

    downstream_failure(addr_, raddr_);

    return std::unexpected{Error::CONNECT_FAIL};
  }

  if (log_enabled(INFO)) {
    Log{INFO, this} << "Connected to downstream host";
  }

  // Reset timeout for write.  Previously, we set timeout for connect.
  conn_.wt.repeat = group_->shared_addr->timeout.write;
  ev_timer_again(conn_.loop, &conn_.wt);

  conn_.rlimit.startw();
  conn_.again_rt();

  ev_set_cb(&conn_.wev, writecb);

  if (conn_.tls.ssl) {
    on_read_ = &HttpDownstreamConnection::tls_handshake;
    on_write_ = &HttpDownstreamConnection::tls_handshake;

    return {};
  }

  signal_write_ = &HttpDownstreamConnection::actual_signal_write;

  connect_blocker->on_success();

  ev_set_cb(&conn_.rt, timeoutcb);
  ev_set_cb(&conn_.wt, timeoutcb);

  on_read_ = &HttpDownstreamConnection::read_clear;
  on_write_ = &HttpDownstreamConnection::write_first;

  return {};
}

std::expected<void, Error> HttpDownstreamConnection::on_read() {
  return on_read_(*this);
}

std::expected<void, Error> HttpDownstreamConnection::on_write() {
  return on_write_(*this);
}

void HttpDownstreamConnection::on_upstream_change(Upstream *upstream) {}

void HttpDownstreamConnection::signal_write() { signal_write_(*this); }

void HttpDownstreamConnection::actual_signal_write() {
  ev_feed_event(conn_.loop, &conn_.wev, EV_WRITE);
}

const std::shared_ptr<DownstreamAddrGroup> &
HttpDownstreamConnection::get_downstream_addr_group() const {
  return group_;
}

DownstreamAddr *HttpDownstreamConnection::get_addr() const { return addr_; }

bool HttpDownstreamConnection::poolable() const {
  return !group_->retired && reusable_;
}

const Address *HttpDownstreamConnection::get_raddr() const { return raddr_; }

} // namespace shrpx
